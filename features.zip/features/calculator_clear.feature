#Author:

@logic
Feature: Calculator - Clear button 'C' functionality

  # Risk: ensures C resets both display and internal expression.
  Scenario: Clear resets the calculator
    Given the calculator app is open
    When I input the sequence "99C"
    Then the display should show "0"
    And the internal expression should be ""

  # Risk: ensures C clears error state to allow new input.
  Scenario: Clear resets error state
    Given the calculator app is open
    When I input the sequence "10/0="
    Then the display should show "Error"
    When I input the sequence "C"
    Then the display should show "0"
    And the internal expression should be ""
