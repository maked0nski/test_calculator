#Author:

@gui
Feature: Calculator - App startup

  # Risk: validates the GUI launches with correct default state and title.
  Scenario: App opens with default display and title
    Given the GUI calculator app is open
    Then the display should show "0"
    And the window title should be "Calculator"
