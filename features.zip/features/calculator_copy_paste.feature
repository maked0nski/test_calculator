#Author:

@logic
Feature: Calculator - Edit operations

  # Risk: ensures backspace removes only the last character.
  Scenario Outline: Backspace removes last input
    Given the calculator app is open
    When I input the sequence "<sequence>"
    Then the display should show "<result>"

    Examples:
      | sequence | result |
      | 99BACK      | 9      |
      | 5+BACK      | 5      |
      | 7BACKBACK      | 0      |
