#Author:

@logic
Feature: Calculator - Negative and edge cases

  # Risk: ensures division by zero is handled safely.
  Scenario Outline: Division by zero returns Error
    Given the calculator app is open
    When I input the sequence "<sequence>"
    Then the display should show "Error"

    Examples:
      | sequence |
      | 2.2/0=   |
      | 0/0=     |
      | SIGN5/0=    |

  # Risk: ensures invalid sequences show Error.
  Scenario Outline: Invalid sequences return Error
    Given the calculator app is open
    When I input the sequence "<sequence>"
    Then the display should show "Error"

    Examples:
      | sequence |
      | -=       |
      | 5-=      |
      | 5..2=    |
      | .5.2=    |

  # Risk: confirms operator replacement behavior.
  Scenario Outline: Consecutive operators replace the previous one
    Given the calculator app is open
    When I input the sequence "<sequence>"
    Then the display should show "<result>"

    Examples:
      | sequence | result |
      | 5++5=    | 10     |
      | 5+-5=    | 0      |
      | 9*SIGN3= | -27    |

  # Risk: ensures operator-first input does not corrupt state.
  Scenario Outline: Operator as first key
    Given the calculator app is open
    When I input the sequence "<sequence>"
    Then the display should show "<result>"

    Examples:
      | sequence | result |
      | +5=      | 5      |
      | *5=      | 5      |
      | /5=      | 5      |
      | -5=      | -5     |
