#Author:

@logic
Feature: Calculator - Basic math operations verification

  # Risk: verifies basic arithmetic for integer values.
  Scenario Outline: Basic math with integers
    Given the calculator app is open
    When I input the sequence "<sequence>"
    Then the display should show "<result>"

    Examples:
      | sequence | result |
      | 2+2=     | 4      |
      | 2-2=     | 0      |
      | 2*3=     | 6      |
      | 10/2=    | 5      |

  # Risk: verifies arithmetic with decimals.
  Scenario Outline: Basic math with decimals
    Given the calculator app is open
    When I input the sequence "<sequence>"
    Then the display should show "<result>"

    Examples:
      | sequence | result |
      | 2.2+2.2= | 4.4    |
      | 2.3-2.1= | 0.2    |
      | 39*3.1=  | 120.9  |
      | 10/2.5=  | 4      |

  # Risk: verifies negative numbers using sign toggle.
  Scenario Outline: Math with negative numbers using "SIGN"
    Given the calculator app is open
    When I input the sequence "<sequence>"
    Then the display should show "<result>"

    Examples:
      | sequence | result |
      | 2.2+SIGN2.2=| 0      |
      | 2.3-SIGN2.1=| 4.4    |
      | 39*SIGN3.1= | -120.9 |
      | SIGN10/SIGN2.5=| 4      |
