Feature: Basic Calculator - UI and Logic
  The calculator supports +, -, *, /, integers, decimals, and unary minus.
  It has no parentheses or memory functions.

  Background:
    Given the calculator app is open
    And the display shows "0"

  # Risk: verifies core arithmetic across number types and unary minus.
  Scenario Outline: Happy path calculations with mixed number types
    When I input the sequence "<sequence>"
    Then the display should show "<result>"

    Examples:
      | sequence        | result |
      | 2+2=            | 4      |
      | 7-5=            | 2      |
      | 6*3=            | 18     |
      | 8/4=            | 2      |
      | 2.5+1.25=       | 3.75   |
      | 5.5-2=          | 3.5    |
      | 2.5*2=          | 5      |
      | 7.5/2.5=        | 3      |
      | -5+2=           | -3     |
      | -5*SIGN2=       | 10     |
      | -7/2=           | -3.5   |

  # Risk: ensures "+/-" toggles the sign of the current or next number.
  Scenario Outline: Sign toggle for negative numbers
    When I input the sequence "<sequence>"
    Then the display should show "<result>"

    Examples:
      | sequence | result |
      | SIGN5=      | -5     |
      | 5SIGN=      | -5     |
      | 5+SIGN2=    | 3      |
      | 5*SIGN2=    | -10    |
      | -5SIGN=     | 5      |
      | 9=SIGN      | -9     |
      | 12.5=SIGN   | -12.5  |
      | 7SIGNBACK      | -      |

  # Risk: confirms rounding behavior to 8 decimals and handling of large values.
  Scenario Outline: Boundary values and precision
    When I input the sequence "<sequence>"
    Then the display should show "<result>"

    Examples:
      | sequence                         | result          |
      | 1/3=                             | 0.33333333      |
      | 2/3=                             | 0.66666667      |
      | 0.123456789+0=                   | 0.12345679      |
      | 123456789.123456789+0=           | 123456789.12345679 |
      | 99999999*99999999=               | 9999999800000001 |
      | 1000000000+1000000000=           | 2000000000      |

  # Risk: ensures division by zero is handled safely.
  Scenario Outline: Division by zero returns Error
    When I input the sequence "<sequence>"
    Then the display should show "Error"

    Examples:
      | sequence |
      | 5/0=     |
      | 0/0=     |
      | -5/0=    |

  # Risk: guards against invalid token sequences and malformed decimals.
  Scenario Outline: Invalid sequences and malformed numbers show Error
    When I input the sequence "<sequence>"
    Then the display should show "Error"

    Examples:
      | sequence |
      | -=       |
      | 5-=      |
      | 5..2=    |
      | .5.2=    |

  # Risk: clarifies operator replacement behavior instead of erroring.
  Scenario Outline: Consecutive operators replace the previous one
    When I input the sequence "<sequence>"
    Then the display should show "<result>"

    Examples:
      | sequence | result |
      | 5++5=    | 10     |
      | 5+-5=    | 0      |
      | 9*SIGN3= | -27    |

  # Risk: ensures clear button resets state and display.
  Scenario Outline: Clear button resets the calculator
    When I input the sequence "<sequence>"
    Then the display should show "0"

    Examples:
      | sequence |
      | 12C      |
      | -7.5C    |
      | 9+1C     |

  # Risk: backspace should remove only the last symbol and return to 0 if empty.
  Scenario Outline: Backspace removes the last character
    When I input the sequence "<sequence>"
    Then the display should show "<result>"

    Examples:
      | sequence | result |
      | 123BACK     | 12     |
      | 5+BACK      | 5      |
      | 7BACKBACK      | 0      |
      | -BACK       | 0      |

  # Risk: verifies behavior when "=" is pressed with no valid operand.
  Scenario Outline: Equals with empty or partial input
    When I input the sequence "<sequence>"
    Then the display should show "<result>"

    Examples:
      | sequence | result |
      | =        | 0      |
      | +=       | 0      |
      | -=       | Error  |

  # Risk: ensures operator-first input does not corrupt state.
  Scenario Outline: Operator as first key
    When I input the sequence "<sequence>"
    Then the display should show "<result>"

    Examples:
      | sequence | result |
      | +5=      | 5      |
      | *5=      | 5      |
      | /5=      | 5      |
      | -5=      | -5     |

  # Risk: validates GUI flow and widget state, not just logic.
  Scenario Outline: GUI integration - basic operations
    Given the GUI calculator app is open
    When I input the sequence "<sequence>"
    Then the display should show "<result>"

    Examples:
      | sequence | result |
      | 2+2=     | 4      |
      | 7-5=     | 2      |
      | 6*3=     | 18     |
      | 8/4=     | 2      |

  # Risk: validates GUI handling of sign toggle and clear/backspace.
  Scenario Outline: GUI integration - sign toggle and edit keys
    Given the GUI calculator app is open
    When I input the sequence "<sequence>"
    Then the display should show "<result>"

    Examples:
      | sequence    | result |
      | SIGN5=      | -5     |
      | 5SIGNBACK   | -      |
      | 12BACK      | 1      |
      | 9+1C        | 0      |