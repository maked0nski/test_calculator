#Author:

@gui
Feature: Calculator - UI verification tests

  # Risk: ensures display updates with typed input.
  Scenario Outline: UI reflects input sequence
    Given the GUI calculator app is open
    When I input the sequence "<sequence>"
    Then the display should show "<result>"

    Examples:
      | sequence | result |
      | 123      | 123    |
      | 9+1      | 9+1    |
      | 7.5*2    | 7.5*2  |

  # Risk: ensures editing keys update display as expected in GUI.
  Scenario Outline: UI edit keys
    Given the GUI calculator app is open
    When I input the sequence "<sequence>"
    Then the display should show "<result>"

    Examples:
      | sequence | result |
      | 12BACK      | 1      |
      | 5+BACK      | 5      |
      | 99C      | 0      |
